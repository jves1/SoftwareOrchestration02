# Group1ClubMembership
The application will serve as a centralized platform for a club membership chairman to manage a list of members.  Specifically, to add, update, delete and report on membership.
