import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends JFrame implements ActionListener {

    private JButton addButton, updateButton, deleteButton, reportButton;

    public MainMenu() {
        // Frame initialization
        setTitle("Club Membership Management Application");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Layout
        setLayout(new GridLayout(4, 1, 10, 10));

        // Initialize buttons
        addButton = new JButton("Add Member");
        updateButton = new JButton("Update Member");
        deleteButton = new JButton("Delete Member");
        reportButton = new JButton("Generate Report");

        // Add action listeners
        addButton.addActionListener(this);
        updateButton.addActionListener(this);
        deleteButton.addActionListener(this);
        reportButton.addActionListener(this);

        // Add buttons to frame
        add(addButton);
        add(updateButton);
        add(deleteButton);
        add(reportButton);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == addButton) {
            // Open Add Member window
            System.out.println("Add Member clicked");
            EventQueue.invokeLater(() -> {
                AddMember addMember = new AddMember();
                addMember.setVisible(true);
            });
        } else if (e.getSource() == updateButton) {
            // Open Update Member window
            System.out.println("Update Member clicked");
            EventQueue.invokeLater(() -> {
                UpdateMember updateMember = new UpdateMember();
                updateMember.setVisible(true);
            });
        } else if (e.getSource() == deleteButton) {
            // Open Delete Member window
            System.out.println("Delete Member clicked");
            EventQueue.invokeLater(() -> {
                DeleteMember deleteMember = new DeleteMember();
                deleteMember.setVisible(true);
            });
        } else if (e.getSource() == reportButton) {
            // Open Report Generation window
            System.out.println("Generate Report clicked");
            EventQueue.invokeLater(() -> {
                Report report = new Report();
                report.setVisible(true);
            });
        }
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            MainMenu mainMenu = new MainMenu();
            mainMenu.setVisible(true);
        });
    }
}
