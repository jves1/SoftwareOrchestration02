import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class AddMember extends JFrame implements ActionListener {

    private JTextField memberIdField, firstNameField, lastNameField, emailField, duesPaidField, duesPaidDateField, renewalDateField;
    private JComboBox<String> membershipLevelBox, statusBox;
    private JButton submitButton, cancelButton;
    private DatabaseUtil databaseUtil;

    public AddMember() {
        databaseUtil = new DatabaseUtil(); // Assuming a no-argument constructor for simplicity

        // Frame initialization
        setTitle("Add Member");
        setSize(350, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

     // North section - Title
        JLabel titleLabel = new JLabel("Add New Member", JLabel.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        // Center section - Form
        JPanel formPanel = new JPanel(new GridLayout(0, 2));
        formPanel.add(new JLabel("Member ID:"));
        memberIdField = createFormattedIDField();
        formPanel.add(memberIdField);

        formPanel.add(new JLabel("First Name:"));
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField);

        formPanel.add(new JLabel("Last Name:"));
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField);

        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField(20);
        formPanel.add(emailField);

        formPanel.add(new JLabel("Dues Paid:"));
        duesPaidField = new JTextField(20);
        formPanel.add(duesPaidField);

        formPanel.add(new JLabel("Dues Paid Date (YYYY-MM-DD):"));
        duesPaidDateField = createFormattedDateField();
        formPanel.add(duesPaidDateField);

        formPanel.add(new JLabel("Renewal Date (YYYY-MM-DD):"));
        renewalDateField = createFormattedDateField();
        formPanel.add(renewalDateField);

        formPanel.add(new JLabel("Membership Level:"));
        String[] levels = {"Level1", "Level2", "Level3"};
        membershipLevelBox = new JComboBox<>(levels);
        formPanel.add(membershipLevelBox);

        formPanel.add(new JLabel("Status:"));
        String[] statuses = {"Active", "Inactive"};
        statusBox = new JComboBox<>(statuses);
        formPanel.add(statusBox);

        add(formPanel, BorderLayout.CENTER);

        // South section - Buttons
        JPanel buttonPanel = new JPanel();
        submitButton = new JButton("Submit");
        cancelButton = new JButton("Cancel");
        submitButton.addActionListener(this);
        cancelButton.addActionListener(this);
        buttonPanel.add(submitButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == submitButton) {
            try {
                // Validate and parse data from fields
                // Validation before submission
                String memberIdValidate = memberIdField.getText().trim();
                String firstNameValidate = firstNameField.getText().trim();
                String lastNamValidatee = lastNameField.getText().trim();
                String emailValidate = emailField.getText().trim();
                String duesPaidValidate = duesPaidField.getText().trim();
                String duesPaidDateValidate = duesPaidDateField.getText().trim();
                String renewalDateValidate = renewalDateField.getText().trim();

                // Check if any field is empty
                if (memberIdValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Member ID is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (firstNameValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "First Name is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (lastNamValidatee.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Last Name is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (emailValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Email is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (duesPaidValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Dues paid is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (duesPaidDateValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Dues paid date is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (renewalDateValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Renewal date is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            	
            	
            	
                int memberId = Integer.parseInt(memberIdField.getText());
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String email = emailField.getText();
                double duesPaid = Double.parseDouble(duesPaidField.getText());
                Date duesPaidDate = parseDate(duesPaidDateField.getText());
                Date renewalDate = parseDate(renewalDateField.getText());
                String membershipLevel = (String) membershipLevelBox.getSelectedItem();
                String status = (String) statusBox.getSelectedItem();

                // Call method to add member data to the database
                boolean success = databaseUtil.addMember(memberId, firstName, lastName, email, duesPaid, duesPaidDate, renewalDate, membershipLevel, status);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Member added successfully!");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to add member.");
                }
            } catch (NumberFormatException | ParseException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input: " + ex.getMessage());
            }
        } else if (e.getSource() == cancelButton) {
            dispose();
        }
    }

    private Date parseDate(String dateString) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        return new Date(formatter.parse(dateString).getTime());
    }
    
    private JFormattedTextField createFormattedIDField() {
        MaskFormatter idFormatter = null;
        try {
            idFormatter = new MaskFormatter("######");
            idFormatter.setValidCharacters("0123456789");
            //idFormatter.setPlaceholderCharacter('_');
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new JFormattedTextField(idFormatter);
    }
    
    private JFormattedTextField createFormattedDateField() {
        MaskFormatter dateFormatter = null;
        try {
            dateFormatter = new MaskFormatter("####-##-##");
            dateFormatter.setPlaceholderCharacter('_');
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new JFormattedTextField(dateFormatter);
    }

//    public static void main(String[] args) {
//        EventQueue.invokeLater(() -> {
//            AddMember addMember = new AddMember();
//            addMember.setVisible(true);
//        });
//    }
}