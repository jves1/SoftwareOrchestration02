import javax.swing.*;
import javax.swing.text.MaskFormatter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class UpdateMember extends JFrame implements ActionListener {

    private JTextField memberIdField, firstNameField, lastNameField, emailField, duesPaidField;
    private JFormattedTextField duesPaidDateField, renewalDateField;
    private JComboBox<String> membershipLevelBox, statusBox;
    private JButton searchButton, updateButton, cancelButton;
    private DatabaseUtil databaseUtil;

    public UpdateMember() {
        databaseUtil = new DatabaseUtil(); // Assuming a no-argument constructor

        // Frame initialization
        setTitle("Update Member");
        setSize(400, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // North section - Title and Member ID Search
        JPanel northPanel = new JPanel(new FlowLayout());
        northPanel.add(new JLabel("Member ID:"));
        memberIdField = createFormattedIDField();
        memberIdField.setPreferredSize(new Dimension(100, 20));
        northPanel.add(memberIdField);
        searchButton = new JButton("Search");
        searchButton.addActionListener(this);
        northPanel.add(searchButton);
        add(northPanel, BorderLayout.NORTH);

        // Center section - Form
        JPanel formPanel = new JPanel(new GridLayout(0, 2));

        // Member First Name
        formPanel.add(new JLabel("First Name:"));
        firstNameField = new JTextField(20);
        formPanel.add(firstNameField);

        // Member Last Name
        formPanel.add(new JLabel("Last Name:"));
        lastNameField = new JTextField(20);
        formPanel.add(lastNameField);

        // Member Email
        formPanel.add(new JLabel("Email:"));
        emailField = new JTextField(20);
        formPanel.add(emailField);

        // Dues Paid
        formPanel.add(new JLabel("Dues Paid:"));
        duesPaidField = new JTextField(20);
        formPanel.add(duesPaidField);

        // Dues Paid Date
        formPanel.add(new JLabel("Dues Paid Date (YYYY-MM-DD):"));
        duesPaidDateField = createFormattedDateField();
        formPanel.add(duesPaidDateField);

        // Renewal Date
        formPanel.add(new JLabel("Renewal Date (YYYY-MM-DD):"));
        renewalDateField = createFormattedDateField();
        formPanel.add(renewalDateField);

        // Membership Level
        formPanel.add(new JLabel("Membership Level:"));
        String[] levels = {"Level1", "Level2", "Level3"};
        membershipLevelBox = new JComboBox<>(levels);
        formPanel.add(membershipLevelBox);

        // Status
        formPanel.add(new JLabel("Status:"));
        String[] statuses = {"Active", "Inactive"};
        statusBox = new JComboBox<>(statuses);
        formPanel.add(statusBox);

        add(formPanel, BorderLayout.CENTER);

        // South section - Buttons
        JPanel buttonPanel = new JPanel();
        updateButton = new JButton("Update");
        cancelButton = new JButton("Cancel");
        updateButton.addActionListener(this);
        cancelButton.addActionListener(this);
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == searchButton) {
            try {
                int memberId = Integer.parseInt(memberIdField.getText());
                String[] memberData = databaseUtil.getMember(memberId);
                if (memberData != null && memberData.length > 0) {
                    // Assuming memberData array follows the order of your database columns
                    firstNameField.setText(memberData[1]); // Index as per your database schema
                    lastNameField.setText(memberData[2]);
                    emailField.setText(memberData[3]);
                    duesPaidField.setText(memberData[4]);
                    duesPaidDateField.setText(memberData[5]);
                    renewalDateField.setText(memberData[6]);
                    membershipLevelBox.setSelectedItem(memberData[7]);
                    statusBox.setSelectedItem(memberData[8]);
                } else {
                    JOptionPane.showMessageDialog(this, "Member not found.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Member ID.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        } else if (e.getSource() == updateButton) {
            try {
            	
                // Validate and parse data from fields
                // Validation before submission
                String memberIdValidate = memberIdField.getText().trim();
                String firstNameValidate = firstNameField.getText().trim();
                String lastNamValidatee = lastNameField.getText().trim();
                String emailValidate = emailField.getText().trim();
                String duesPaidValidate = duesPaidField.getText().trim();
                String duesPaidDateValidate = duesPaidDateField.getText().trim();
                String renewalDateValidate = renewalDateField.getText().trim();

                // Check if any field is empty
                if (memberIdValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Member ID is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (firstNameValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "First Name is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (lastNamValidatee.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Last Name is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (emailValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Email is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (duesPaidValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Dues paid is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (duesPaidDateValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Dues paid date is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (renewalDateValidate.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Renewal date is required.", "Input Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            	
            	
                int memberId = Integer.parseInt(memberIdField.getText());
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                String email = emailField.getText();
                double duesPaid = Double.parseDouble(duesPaidField.getText());
                Date duesPaidDate = Date.valueOf(duesPaidDateField.getText());
                Date renewalDate = Date.valueOf(renewalDateField.getText());
                String membershipLevel = (String) membershipLevelBox.getSelectedItem();
                String status = (String) statusBox.getSelectedItem();

                boolean success = databaseUtil.updateMember(memberId, firstName, lastName, email, duesPaid, duesPaidDate, renewalDate, membershipLevel, status);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Member updated successfully.");
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to update member.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input format.");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, "Invalid date format.");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        } else if (e.getSource() == cancelButton) {
            dispose();
        }
    }
    
    private JFormattedTextField createFormattedIDField() {
        MaskFormatter idFormatter = null;
        try {
            idFormatter = new MaskFormatter("######");
            idFormatter.setValidCharacters("0123456789");
            //idFormatter.setPlaceholderCharacter('_');
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new JFormattedTextField(idFormatter);
    }


    private JFormattedTextField createFormattedDateField() {
        MaskFormatter dateFormatter = null;
        try {
            dateFormatter = new MaskFormatter("####-##-##");
            dateFormatter.setPlaceholderCharacter('_');
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return new JFormattedTextField(dateFormatter);
    }

//    public static void main(String[] args) {
//        EventQueue.invokeLater(() -> {
//            UpdateMember updateMember = new UpdateMember();
//            updateMember.setVisible(true);
//        });
//    }
}
