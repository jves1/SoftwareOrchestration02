import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DeleteMember extends JFrame implements ActionListener {

    private JTextField memberIdField;
    private JButton deleteButton, cancelButton;
    private DatabaseUtil databaseUtil;

    public DeleteMember() {
        databaseUtil = new DatabaseUtil(); // Assuming a no-argument constructor for simplicity

        // Frame initialization
        setTitle("Delete Member");
        setSize(300, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // North section - Title
        JLabel titleLabel = new JLabel("Delete Member", JLabel.CENTER);
        add(titleLabel, BorderLayout.NORTH);

        // Center section - Form
        JPanel formPanel = new JPanel(new GridLayout(1, 2));
        formPanel.add(new JLabel("Member ID:"));
        memberIdField = new JTextField(20);
        formPanel.add(memberIdField);
        add(formPanel, BorderLayout.CENTER);

        // South section - Buttons
        JPanel buttonPanel = new JPanel();
        deleteButton = new JButton("Delete");
        cancelButton = new JButton("Cancel");
        deleteButton.addActionListener(this);
        cancelButton.addActionListener(this);
        buttonPanel.add(deleteButton);
        buttonPanel.add(cancelButton);
        add(buttonPanel, BorderLayout.SOUTH);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == deleteButton) {
            try {
                int memberId = Integer.parseInt(memberIdField.getText());
                boolean memberExists = databaseUtil.getMember(memberId) != null; // Check if member exists
                if (memberExists) {
                    int response = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete member ID " + memberId + "?", "Confirm", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                    if (response == JOptionPane.YES_OPTION) {
                        boolean success = databaseUtil.deleteMember(memberId);
                        if (success) {
                            JOptionPane.showMessageDialog(this, "Member deleted successfully.");
                        } else {
                            JOptionPane.showMessageDialog(this, "Failed to delete member.");
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Member not found.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid Member ID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else if (e.getSource() == cancelButton) {
            dispose();
        }
    }

//    public static void main(String[] args) {
//        EventQueue.invokeLater(() -> {
//            DeleteMember deleteMember = new DeleteMember();
//            deleteMember.setVisible(true);
//        });
//    }
}
