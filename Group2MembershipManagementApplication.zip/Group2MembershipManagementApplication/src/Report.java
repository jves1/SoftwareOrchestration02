import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Report extends JFrame implements ActionListener {

    private JComboBox<String> reportTypeBox;
    private JButton generateButton, cancelButton;
    private JTextArea reportArea;
    private DatabaseUtil databaseUtil;

    public Report() {
        databaseUtil = new DatabaseUtil(); // Assuming a no-argument constructor

        // Frame initialization
        setTitle("Generate Report");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // North section - Dropdown and Buttons
        JPanel northPanel = new JPanel();
        reportTypeBox = new JComboBox<>(new String[]{"All Members", "Active Members", "Inactive Members", "Level1 Members", "Level2 Members", "Level3 Members"});
        northPanel.add(reportTypeBox);
        generateButton = new JButton("Generate");
        cancelButton = new JButton("Cancel");
        generateButton.addActionListener(this);
        cancelButton.addActionListener(this);
        northPanel.add(generateButton);
        northPanel.add(cancelButton);
        add(northPanel, BorderLayout.NORTH);

        // Center section - Report display area
        reportArea = new JTextArea();
        reportArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(reportArea);
        add(scrollPane, BorderLayout.CENTER);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == generateButton) {
            String selectedReport = (String) reportTypeBox.getSelectedItem();
            List<String[]> reportData;
            switch (selectedReport) {
                case "All Members":
                    reportData = databaseUtil.allMemberReport();
                    break;
                case "Active Members":
                    reportData = databaseUtil.statusReport("Active");
                    break;
                case "Inactive Members":
                    reportData = databaseUtil.statusReport("Inactive");
                    break;
                case "Level1 Members":
                    reportData = databaseUtil.levelReport("Level1");
                    break;
                case "Level2 Members":
                    reportData = databaseUtil.levelReport("Level2");
                    break;
                case "Level3 Members":
                    reportData = databaseUtil.levelReport("Level3");
                    break;
                default:
                    reportData = databaseUtil.allMemberReport();
            }

            displayReport(reportData);
        } else if (e.getSource() == cancelButton) {
            dispose();
        }
    }

    private void displayReport(List<String[]> reportData) {         
        StringBuilder reportBuilder = new StringBuilder();

        // Define a format for each column, assuming 3 columns for illustration
        String format = "%-20s %-25s %-25s %-30s %-30s %-30s %-20s %-10s %-15s %n"; // Adjust the widths (-10, -20, -15) as needed

        // Add column headers
        reportBuilder.append(String.format(format, "ID", "First Name", "Last Name", "Email", "Dues Paid", "Dues Paid Date", "Renewal Date", "Level", "Status"));

        // Add data rows
        for (String[] row : reportData) {
            reportBuilder.append(String.format(format, row[0], row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8]));
        }

        reportArea.setText(reportBuilder.toString());
    }

//    public static void main(String[] args) {
//        EventQueue.invokeLater(() -> {
//            Report report = new Report();
//            report.setVisible(true);
//        });
//    }
}
