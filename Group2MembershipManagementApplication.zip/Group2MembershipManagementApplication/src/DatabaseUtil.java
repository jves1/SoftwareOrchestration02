import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DatabaseUtil {

    private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/membershipschema";
    private static final String DATABASE_USER = "root";
    private static final String DATABASE_PASSWORD = "";

    public DatabaseUtil() {
        // Load the JDBC driver if necessary (for older versions of JDBC)
        // Class.forName("com.mysql.cj.jdbc.Driver");
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);
    }

    public boolean addMember(int memberId, String firstName, String lastName, String email, double duesPaid, Date duesPaidDate, Date renewalDate, String membershipLevel, String status) {
        String sql = "INSERT INTO members (member_id, first_name, last_name, email_address, dues_paid, dues_paid_date, renewal_date, level, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            stmt.setString(2, firstName);
            stmt.setString(3, lastName);
            stmt.setString(4, email);
            stmt.setDouble(5, duesPaid);
            stmt.setDate(6, duesPaidDate);
            stmt.setDate(7, renewalDate);
            stmt.setString(8, membershipLevel);
            stmt.setString(9, status);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public String[] getMember(int memberId) {
        String sql = "SELECT * FROM members WHERE member_id = ?";
        String[] memberData = null;

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, memberId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    int columnCount = rs.getMetaData().getColumnCount();
                    memberData = new String[columnCount];
                    for (int i = 0; i < columnCount; i++) {
                        memberData[i] = rs.getString(i + 1); // ResultSet columns are 1-based
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return memberData;
    }

    public boolean updateMember(int memberId, String firstName, String lastName, String email, double duesPaid, Date duesPaidDate, Date renewalDate, String membershipLevel, String status) {
        String sql = "UPDATE members SET first_name = ?, last_name = ?, email_address = ?, dues_paid = ?, dues_paid_date = ?, renewal_date = ?, level = ?, status = ? WHERE member_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setDouble(4, duesPaid);
            stmt.setDate(5, duesPaidDate);
            stmt.setDate(6, renewalDate);
            stmt.setString(7, membershipLevel);
            stmt.setString(8, status);
            stmt.setInt(9, memberId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public boolean deleteMember(int memberId) {
        String sql = "DELETE FROM members WHERE member_id = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Example report method
    public List<String[]> statusReport(String status) {
        List<String[]> members = new ArrayList<>();
        String sql = "SELECT * FROM members WHERE status = ?";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, status);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    String[] data = new String[9]; // Assuming 9 fields for member
                    for (int i = 1; i <= 9; i++) {
                        data[i-1] = rs.getString(i);
                    }
                    members.add(data);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return members;
    }
    public List<String[]> allMemberReport() {
        String sql = "SELECT * FROM members";
        List<String[]> reportData = new ArrayList<>();

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int columnCount = rs.getMetaData().getColumnCount();
                    String[] rowData = new String[columnCount];
                    for (int i = 0; i < columnCount; i++) {
                        rowData[i] = rs.getString(i + 1);
                    }
                    reportData.add(rowData);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reportData;
    }

    public List<String[]> levelReport(String level) {
        String sql = "SELECT * FROM members WHERE level = ?";
        List<String[]> reportData = new ArrayList<>();

        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, level);

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int columnCount = rs.getMetaData().getColumnCount();
                    String[] rowData = new String[columnCount];
                    for (int i = 0; i < columnCount; i++) {
                        rowData[i] = rs.getString(i + 1);
                    }
                    reportData.add(rowData);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return reportData;
    }
    

    // Other report methods...

    // You can add more methods for specific queries and operations as needed.
}

